import React from 'react'

function Heart() {
    return (
        <div>
            <h1>heart</h1>
        </div>
    )
}

export default Heart
