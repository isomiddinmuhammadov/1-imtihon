import React from 'react'
import './Tarkib.css'

function Tarkib() {
  return (
    <div className='tarkibb'>
        <p>Paxta <span>80%</span></p>
        <p>Poliester <span>20%</span></p>
    </div>
  )
}

export default Tarkib