import React from 'react'
import './Tavsif.css'

function Tavsif() {
    return (
        <div className='tavsiff'>
            <p>Eng so'nggi tendentsiyalardan xabardor bo'lishni xohlaydigan zamonaviy erkaklar uchun biz sizga RAMONSO brendimiz tomonidan taqdim etilgan bomberni olishingizni maslahat beramiz. Ikkita cho'ntak bilan to'ldirilgan, tik yoqa, kamar va manjetli engil vetrovka yuqori sifatli issiq trikotajdan tikilgan. Eng mayda detallarga e'tibor bilan ishlangan bu tekis rangli ko'ylagi ham lakonik shimlar, ham jinsi shimlar bilan yaxshi birlashadi. Ushbu parametr tasodifiy ko'rinishni mukammal ravishda to'ldiradi va biznes uslubiga yangilik keltiradi.

                Ilgari tarixiy bomber aviator uchuvchisi, yozgi kurtka, klub kurtka, bomber kurtka, trikotaj piloti, tolstovka bomber bo'lgan va bugungi kunda bu qisqa yoshlar klubniy olimpiykasi, ular mohirlik bilan uyg'unlashtirgan vetrovka - turli xil obrazlar . Umuman olganda, zamonaviy bomber har qanday yoshdagi, yilning istalgan vaqtida, har qanday ob-havo, har qanday kayfiyat uchun obrazingizni ustalik bilan o'zgartirish imkonini beradi.Bizda chegirmalar ham bor:

                200 000 so'mdan xarid qilganda chegirma 20 000 so'm - promo-kod 0020B-RMS23

                350 000 so'mdan boshlab 40 000 so'm chegirma - 0020B-RMS40 promokodi

                Promo-kod 31.12.2023 yilgacha amal qiladi</p>
        </div>
    )
}

export default Tavsif