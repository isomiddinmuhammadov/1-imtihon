import React from 'react'
import './Korsatma.css'

function Korsatma() {
  return (
    <div className='korsatmaa'>
        <p>
            30С suvda delikat rejim kir yuvish mashinasida yoki q'olda yuvish tavsiya etiladi

Maxsus sumkalar yoki nozik yuvish rejimidan foydalanish tavsiya etiladi (qo'lda) - bu sizning kiyimingizni umrini oshiradi.
        </p>
    </div>
  )
}

export default Korsatma