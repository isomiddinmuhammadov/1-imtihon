import React from 'react'
import './Sharhlar.css'

function Sharhlar() {
  return (
    <div className='sharhlarr'>

    </div>
  )
}

export default Sharhlar