import React from 'react'
import './CartData.css'

function CartData() {
    return (
        <div className='cart_data'>
            <h1>cart data</h1>
        </div>
    )
}

export default CartData
