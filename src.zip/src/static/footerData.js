export const footerData = [
    {
        title: "Topshirish punktlari",
        lists: [
          "Vakansiyalar"
        ]
    },
    {
        title: "Biz bilan bogʻlanish",
        lists: [
        "Savol-Javob"  
        ]
    },
    {
        title: "Uzumda soting",
        lists: [
            "Sotuvchi kabinetiga kirish"
        ]
    },
   
]